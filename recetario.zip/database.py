import sqlite3

def crear_base_de_datos():
    conexion = sqlite3.connect("recetas.db")
    cursor = conexion.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS recetas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            ingredientes TEXT NOT NULL,
            pasos TEXT NOT NULL,
            tiempo_coccion TEXT,
            imagen TEXT  -- Aquí guardaremos la ruta de la foto
        )
    ''')
    conexion.commit()
    conexion.close()

def guardar_receta(nombre, ingredientes, tiempo, imagen):
    conexion = sqlite3.connect("recetas.db")
    cursor = conexion.cursor()
    cursor.execute("INSERT INTO recetas (nombre, ingredientes, pasos, tiempo_coccion, imagen) VALUES (?, ?, ?, ?, ?)",
                   (nombre, ingredientes, "Pasos...", tiempo, imagen))
    conexion.commit()
    conexion.close()

def actualizar_receta_db(id_receta, nombre, ingredientes, tiempo, imagen):
    conexion = sqlite3.connect("recetas.db")
    cursor = conexion.cursor()
    cursor.execute("UPDATE recetas SET nombre=?, ingredientes=?, tiempo_coccion=?, imagen=? WHERE id=?",
                   (nombre, ingredientes, tiempo, imagen, id_receta))
    conexion.commit()
    conexion.close()

def obtener_todas_las_recetas():
    conexion = sqlite3.connect("recetas.db")
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM recetas")
    datos = cursor.fetchall()
    conexion.close()
    return datos

def eliminar_receta_db(id_receta):
    conexion = sqlite3.connect("recetas.db")
    cursor = conexion.cursor()
    cursor.execute("DELETE FROM recetas WHERE id = ?", (id_receta,))
    conexion.commit()
    conexion.close()

crear_base_de_datos()
