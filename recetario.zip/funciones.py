def guardar_receta(nombre, ingredientes, pasos, tiempo, categoria):
    conexion = sqlite3.connect("recetas.db")
    cursor = conexion.cursor()
    
    consulta = "INSERT INTO recetas (nombre, ingredientes, pasos, tiempo_coccion, categoria) VALUES (?, ?, ?, ?, ?)"
    cursor.execute(consulta, (nombre, ingredientes, pasos, tiempo, categoria))
    
    conexion.commit()
    conexion.close()
    print(f"Receta de '{nombre}' guardada con éxito.")

def obtener_todas_las_recetas():
    conexion = sqlite3.connect("recetas.db")
    cursor = conexion.cursor()
    
    cursor.execute("SELECT * FROM recetas")
    datos = cursor.fetchall()
    
    conexion.close()
    return datos
