/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putunsgf.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 10:20:33 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/06/11 17:13:29 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_putunsgf(unsigned int n)
{
	int	count;

	count = 0;
	if (n > 9)
		count += ft_putunsgf(n / 10);
	count += ft_putcharf(n % 10 + '0');
	return (count);
}
/*#include <stdio.h>

int main()
{
	unsigned int number = 12345;
	size_t count = 0;
	ft_putunsgf(number, &count);
	ft_putcharf('\n', &count);
	return (0);
}*/