/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 12:20:15 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/06/12 18:51:15 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"
#include <stdio.h>

int main()
{
	char	*ptr;

	ptr = "holamundo";
	int	result1;
	int	result2;
	int result3;
	int result4;
	int result5;
	int result6;
	int result7;

	int x = 0;
	printf("printf: %p %p\n", &x, NULL);
    ft_printf("ft_printf: %p %p\n", &x, NULL);
	
	ft_printf("-------Prueba ft_printf-------\n\n");
	result1= ft_printf("Mi nombre es %s, y la primera letra es la %c\n", "Jose Carlos", 'J');
	ft_printf("Ha contabilizado %d caracteres\n\n", result1);

	result2 = ft_printf("La dirección de memoria del puntero es %p\n", &ptr);
	ft_printf("Ha contabilizado %d caracteres\n\n", result2);

	result3 = ft_printf("Los números mágicos son %d y %i\n", 4, 2);
	ft_printf("Ha contabilizado %d caracteres\n\n", result3);

	result4 = ft_printf("Un ejemplo de unsigned int sería %u\n", 42);
	ft_printf("Ha contabilizado %d caracteres\n\n", result4);

	result5 = ft_printf("Hexadecimal mayúscula %X y en minúscula %x\n", 0xFF, 0x2A);
	ft_printf("Ha contabilizado %d caracteres\n\n", result5);
	
	result6 = ft_printf("Prueba de %%\n");
	ft_printf("Ha contabilizado %d caracteres\n\n", result6);

	result7 = ft_printf("%c%c%c:Estudiamos en %s, donde estamos viendo números hexadecimales en minúsculas %x y en mayúsculas %X, aunque no nos podemos olvidar de los unsigned int %u y de los punteros que se localizan mediante números hexadecimales, como el siguiente puntero %p. Finalmente la respuesta a todo son %d de posibilidades que acaban resultando como el número mágico %i\n", 'T', 'X', 'T', "42 Telefónica", 0xA5B, 0xFF, -1500, &ptr, 1000000, 42);
	ft_printf("Ha contabilizado %d caracteres\n\n", result7);

	return (0);
}