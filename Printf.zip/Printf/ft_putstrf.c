/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstrf.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/08 18:43:25 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/06/11 17:13:29 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_putstrf(char *s)
{
	int	i;
	int	count;

	i = 0;
	count = 0;
	if (s == NULL)
		return (ft_putstrf("(null)"));
	while (s[i])
	{
		count += ft_putcharf(s[i]);
		i++;
	}
	return (count);
}
/*
#include <stdio.h>

int	main()
{
	int result;

	
	result = printf("El string es: %s", "holamundo");
	printf("\n");
	printf("resultado: %d", result);
	return (0);
}
*/