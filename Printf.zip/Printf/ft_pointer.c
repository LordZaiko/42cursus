/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pointer.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/07 10:25:10 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/06/12 18:05:19 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_pointer(intptr_t ptr)
{
	size_t	counter;

	counter = 0;
	if (!ptr)
		return (write(1, "(nil)", 5));
	counter += write (1, "0x", 2);
	counter += ft_puthex(ptr, 'x');
	return (counter);
}
