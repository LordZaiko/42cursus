/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/08 17:37:04 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/06/12 16:39:16 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include <unistd.h>
# include <stdlib.h>

int		ft_putcharf(char c);
int		ft_putnbrf(int nb);
int		ft_putstrf(char *s);
int		ft_putunsgf(unsigned int n);
int		ft_puthex(unsigned long long nb, char c);
int		ft_pointer(intptr_t ptr);

int		ft_printf(const char *str, ...);

#endif