/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalnum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 10:21:47 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/05/07 10:21:47 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isalnum(int c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
		|| (c >= '0' && c <= '9'))
		return (1);
	return (0);
}
/*#include <stdio.h>

int main()
{
    printf("%d \n", ft_isalnum('5'));
    printf("%d \n", ft_isalnum('c'));
    printf("%d \n", ft_isalnum('A'));
    printf("%d \n", ft_isalnum(' '));
    return (0);
}*/
