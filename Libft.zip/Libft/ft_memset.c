/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 10:23:50 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/05/07 10:23:50 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>
#include <stdio.h>

void	*ft_memset(void *dest, int c, size_t len)
{
	size_t			i;
	unsigned char	*buffer;

	i = 0;
	buffer = (unsigned char *)dest;
	while (i < len)
	{
		buffer[i] = (unsigned char)c;
		i++;
	}
	return (dest);
}

/*int main() 
{
    char buffer[10];
    memset(buffer, 'a', sizeof(buffer));
    printf("Buffer: %s\n", buffer);
    return 0;
}*/
