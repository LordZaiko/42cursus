/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 10:23:39 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/05/07 10:23:39 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *dest, const void *src, size_t n)
{
	size_t	i;
	char	*source;
	char	*dst;

	i = 0;
	source = (char *)src;
	dst = (char *)dest;
	if (!source && !dst)
		return (0);
	while (i < n)
	{
		dst[i] = source[i];
		i++;
	}
	return (dst);
}
/*#include <stdio.h>

int main()
{
    char    src[] = "hola";
    char    dest[] = "buenas tardes";

    ft_memcpy(dest, src, 4);

    printf("%s", ft_memcpy(dest, dest, 4));
    return (0);
}*/
