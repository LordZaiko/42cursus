/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 10:23:23 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/05/08 11:02:14 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>
#include <stdio.h>

void	*ft_memchr(const void *s, int c, size_t n)
{
	size_t				i;
	char				*str;

	i = 0;
	str = (char *)s;
	while (i < n)
	{
		if (str[i] == (char)c)
			return (&str[i]);
		i++;
	}
	return (NULL);
}

/*int main() 
{
    const char *str = "Hola mi gente!";
    char c = 'm';
    char *result = memchr(str, c, strlen(str));
    if (result != NULL) 
    {
        printf("Carácter encontrado: %c\n", *result);
    } else 
    {
        printf("Carácter no encontrado.\n");
    }
    return 0;
}*/
