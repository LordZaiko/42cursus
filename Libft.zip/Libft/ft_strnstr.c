/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 10:30:20 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/05/07 10:30:22 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *str1, const char *tofind, size_t n)
{
	size_t	i;
	size_t	j;

	i = 0;
	if (tofind[i] == '\0')
		return ((char *)str1);
	while (str1[i] && i < n)
	{
		j = 0;
		if (str1[i] == tofind[j])
		{
			while (str1[i + j] == tofind[j] && (i + j) < n)
			{
				if (tofind[j + 1] == '\0')
					return ((char *)str1 + i);
				j++;
			}
		}
		i++;
	}
	return (0);
}
/*#include <stdio.h>

int main()
{
    printf("%s", ft_strnstr("hola mundo", "mundo", 11));
    return (0);
}*/
