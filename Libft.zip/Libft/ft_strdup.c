/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 10:24:39 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/05/08 10:39:11 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>
#include <stdio.h>

char	*ft_strdup(const char *str)
{
	void	*buffer;
	size_t	count;

	count = ft_strlen(str);
	buffer = (char *)malloc((count + 1) * sizeof(char));
	if (buffer == 0)
		return (0);
	else
	{
		ft_memcpy(buffer, str, count + 1);
	}
	return (buffer);
}

/*int main() 
{
    const char *original = "Buenas Señores!";
    char *duplicate = strdup(original);
    if (duplicate != NULL) 
    {
        printf("Copia de cadena: %s\n", duplicate);
        free(duplicate);
    } else 
    {
        printf("Error al duplicar la cadena.\n");
    }
    return 0;
}*/