/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mains.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/04 18:10:23 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/05/08 10:39:19 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Main Isalpha

int main() 
{
    char caracter = 'a';
    if (isalpha(caracter))
        printf("%c es una letra.\n", caracter);
    else
        printf("%c no es una letra.\n", caracter);
    
    return 0;
}

// Main Isdigit

int main() 
{
    char caracter = '5';
    if (isdigit(caracter))
        printf("%c es un digito.\n", caracter);
    else
        printf("%c no es un digito.\n", caracter);
    
    return 0;
}

// Main Isalnum

int main() 
{
    char caracter = '7';
    if (isalnum(caracter))
        printf("%c es alfanumérico.\n", caracter);
    else
        printf("%c no es alfanumérico.\n", caracter);
    
    return 0;
}

// Main Isascii

int main() 
{
    int caracter = 'a';
    if (isascii(caracter))
        printf("%c es un carácter ASCII.\n", caracter);
    else
        printf("%c no es un carácter ASCII.\n", caracter);
    
    return 0;
}

// Main Isprint

int main() 
{
    int caracter = 'a';
    if (isprint(caracter))
        printf("%c es un carácter imprimible.\n", caracter);
    else
        printf("%c no es un carácter imprimible.\n", caracter);
    
    return 0;
}

// Main Strlen

int main() 
{
    const char *cadena = "Que pasa gente!";
    printf("Longitud de la cadena: %zu\n", strlen(cadena));
    return 0;
}

// Main memset

int main() 
{
    char buffer[10];
    memset(buffer, 'a', sizeof(buffer));
    printf("Buffer: %s\n", buffer);
    return 0;
}

// Main Bzero

int main() 
{
    char buffer[10];
    bzero(buffer, sizeof(buffer));
    printf("Buffer: %s\n", buffer);
    return 0;
}

// Main Memcpy

int main() 
{
    char src[] = "Que pasa Gente!";
    char dest[20];
    memcpy(dest, src, sizeof(src));
    printf("Destination: %s\n", dest);
    return 0;
}

// Main Memmove

int main() 
{
    char src[] = "Que Pasa Peña!";
    char dest[20];
    memmove(dest, src, sizeof(src));
    printf("Destination: %s\n", dest);
    return 0;
}

// Main Strlcpy

int main() 
{
    char src[] = "Hola Peña!";
    char dest[20];
    size_t len = strlcpy(dest, src, sizeof(dest));
    printf("Destination: %s\n", dest);
    printf("Length: %zu\n", len);
    return 0;
}

// Main Strlcat

int main() 
{
    char dest[20] = "Hola";
    char src[] = "Señores";
    size_t len = strlcat(dest, src, sizeof(dest));
    printf("Destination: %s\n", dest);
    printf("Length: %zu\n", len);
    return 0;
}

// Main Toupper

int main() 
{
    char lowercase = 'a';
    char uppercase = toupper(lowercase);
    printf("Uppercase: %c\n", uppercase);
    return 0;
}

// Main Tolower

int main() 
{
    char uppercase = 'A';
    char lowercase = tolower(uppercase);
    printf("Lowercase: %c\n", lowercase);
    return 0;
}

// Main Strchr

int main() 
{
    const char *str = "Hola Gente!";
    char c = 'o';
    char *result = strchr(str, c);
    if (result != NULL) 
    {
        printf("Carácter encontrado: %c\n", *result);
    } else 
    {
        printf("Carácter no encontrado.\n");
    }
    return 0;
}

//Main Strrchr

int main() 
{
    const char *str = "Buenas Gente!";
    char c = 'o';
    char *result = strrchr(str, c);
    if (result != NULL) 
    {
        printf("Última aparición encontrada: %c\n", *result);
    } else 
    {
        printf("Carácter no encontrado.\n");
    }
    return 0;
}

// Main Strncmp

int main() 
{
    const char *str1 = "Hola";
    const char *str2 = "Hol";
    int result = strncmp(str1, str2, 4);
    if (result == 0) 
    {
        printf("Las cadenas son iguales.\n");
    } else if (result < 0) 
    {
        printf("La primera cadena es menor que la segunda.\n");
    } else 
    {
        printf("La primera cadena es mayor que la segunda.\n");
    }
    return 0;
}

// Main Memchr

int main() 
{
    const char *str = "Hola mi gente!";
    char c = 'w';
    char *result = memchr(str, c, strlen(str));
    if (result != NULL) 
    {
        printf("Carácter encontrado: %c\n", *result);
    } else 
    {
        printf("Carácter no encontrado.\n");
    }
    return 0;
}

// Main Memcmp

int main() 
{
    const char *str1 = "Hola";
    const char *str2 = "Hol";
    int result = memcmp(str1, str2, 4);
    if (result == 0) 
    {
        printf("Las cadenas son iguales.\n");
    } else if (result < 0) 
    {
        printf("La primera cadena es menor que la segunda.\n");
    } else 
    {
        printf("La primera cadena es mayor que la segunda.\n");
    }
    return 0;
}

// Main Strnstr

int main() 
{
    const char *haystack = "Hola Mundo!";
    const char *needle = "Mundo";
    char *result = strnstr(haystack, needle, strlen(haystack));
    if (result != NULL) 
    {
        printf("Subcadena encontrada: %s\n", result);
    } else 
    {
        printf("Subcadena no encontrada.\n");
    }
    return 0;
}

// Main Atoi

int main() 
{
    const char *str = "12345";
    int number = atoi(str);
    printf("Número convertido: %d\n", number);
    return 0;
}

// Main Calloc

int main() 
{
    size_t num_elements = 5;
    size_t element_size = sizeof(int);
    int *array = calloc(num_elements, element_size);
    if (array != NULL) 
    {
        printf("Memoria asignada correctamente.\n");
        free(array);
    } else 
    {
        printf("Error al asignar memoria.\n");
    }
    return 0;
}

// Main Strdup

int main() 
{
    const char *original = "Buenas Señores!";
    char *duplicate = strdup(original);
    if (duplicate != NULL) 
    {
        printf("Copia de cadena: %s\n", duplicate);
        free(duplicate);
    } else 
    {
        printf("Error al duplicar la cadena.\n");
    }
    return 0;
}


// Main Substr

int main() 
{
    const char *str = "Hola Señores!";
    char *substring = substr(str, 7, 5);
    if (substring != NULL) 
    {
        printf("Subcadena: %s\n", substring);
        free(substring);
    } else 
    {
        printf("Error al obtener la subcadena.\n");
    }
    return 0;
}

// Main Strjoin

int main() 
{
    const char *str1 = "Hola, ";
    const char *str2 = "Señores!";
    char *joined_str = strjoin(str1, str2);
    if (joined_str != NULL) 
    {
        printf("Cadena unida: %s\n", joined_str);
        free(joined_str);
    } else 
    {
        printf("Error al unir cadenas.\n");
    }
    return 0;
}

// Main Strtrim

int main() 
{
    const char *str = "   Hola Señores!   ";
    char *trimmed_str = strtrim(str);
    if (trimmed_str != NULL) 
    {
        printf("Cadena sin espacios en blanco al inicio y al final: \"%s\"\n", trimmed_str);
        free(trimmed_str);
    } else 
    {
        printf("Error al recortar la cadena.\n");
    }
    return 0;
}

// Main Split

int main() 
{
    const char *str = "Buenos dias, Ciudad!";
    const char *delim = ", ";
    int num_tokens;
    char **tokens = split(str, delim, &num_tokens);
    if (tokens != NULL) 
    {
        printf("Número de tokens: %d\n", num_tokens);
        for (int i = 0; i < num_tokens; i++) 
        {
            printf("Token %d: \"%s\"\n", i + 1, tokens[i]);
        }
        free(tokens);
    } else 
    {
        printf("Error al dividir la cadena.\n");
    }
    return 0;
}

// Main Itoa

int main() 
{
    int num = 123;
    char str[20];
    itoa(num, str, 10);
    printf("Número convertido a cadena: %s\n", str);
    return 0;
}

// Main Strmapi

int main() 
{
    const char *str = "Buenas :)";
    char *result = strmapi(str, to_uppercase);
    if (result != NULL) 
    {
        printf("Resultado: %s\n", result);
        free(result);
    } else 
    {
        printf("Error al aplicar la función de mapeo.\n");
    }
    return 0;
}

// Main Striteri

int main() 
{
    char str[] = "Buenas";
    striteri(str, print_index_and_character);
    return 0;
}

// Main Putchar_fd

int main() 
{
    putchar_fd('A', STDOUT_FILENO); 
    putchar_fd('\n', STDOUT_FILENO);
    return 0;
}

// Main Putstr_fd

int main() 
{
    putstr_fd("Buenas, Señores!", STDOUT_FILENO); 
    return 0;
}

// Main Putendl_fd

int main() 
{
    putendl_fd("Buenas, Señores!", STDOUT_FILENO); 
    return 0;
}

// Main Putnbr_fd

int main() 
{
    putnbr_fd(123, STDOUT_FILENO);
    return 0;
}

// Main Lstnew

int main() 
{
    int value = 42;
    t_list *node = lstnew(&value);
    if (node != NULL) 
    {
        printf("Content of the node: %d\n", *(int *)node->content);
        free(node);
    } else 
    {
        printf("Error creating the node.\n");
    }
    return 0;
}

// Main Lstadd_front

int main() 
{
    t_list *head = NULL;
    int value1 = 42;
    int value2 = 24;
    
    t_list *node1 = malloc(sizeof(t_list));
    t_list *node2 = malloc(sizeof(t_list));

    node1->content = &value1;
    node2->content = &value2;

    lstadd_front(&head, node1);
    lstadd_front(&head, node2);

    printf("Content of the first node: %d\n", *(int *)head->content);
    printf("Content of the second node: %d\n", *(int *)head->next->content);

    free(node1);
    free(node2);

    return 0;
}

// Main Lstsize

int main() 
{
    t_list *head = malloc(sizeof(t_list));
    t_list *second = malloc(sizeof(t_list));
    t_list *third = malloc(sizeof(t_list));

    head->next = second;
    second->next = third;
    third->next = NULL;

    printf("Tamaño de la lista: %d\n", lstsize(head));

    free(head);
    free(second);
    free(third);

    return 0;
}

// Main Lstlast

int main() 
{
    t_list *head = malloc(sizeof(t_list));
    t_list *second = malloc(sizeof(t_list));
    t_list *third = malloc(sizeof(t_list));

    head->next = second;
    second->next = third;
    third->next = NULL;

    t_list *last_node = lstlast(head);

    printf("Último nodo content: %p\n", last_node->content);

    free(head);
    free(second);
    free(third);

    return 0;
}

// Main Lstadd_back

int main() 
{
    t_list *head = NULL;
    t_list *new1 = malloc(sizeof(t_list));
    t_list *new2 = malloc(sizeof(t_list));

    new1->content = "first";
    new1->next = NULL;
    new2->content = "second";
    new2->next = NULL;

    lstadd_back(&head, new1);
    lstadd_back(&head, new2);

    while (head != NULL) {
        printf("%s\n", (char *)head->content);
        head = head->next;
    }

    free(new1);
    free(new2);

    return 0;
}

// Main Lstdelone

int main() 
{
    t_list *node = malloc(sizeof(t_list));
    node->content = strdup("Buenas");
    node->next = NULL;

    lstdelone(node, free_content);

    return 0;
}

// Main Lstiter

int	main(void)
{
    t_list	*lst;
    lst = ft_lstnew(ft_strdup("Hola"), sizeof("Hola"));
    ft_lstadd_back(&lst, ft_lstnew(ft_strdup("Mundo"), sizeof("Mundo")));
    ft_lstiter(lst, &print_content);
    ft_lstclear(&lst, &free);
    return (0);
}

// Main Lstmap
