/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 10:23:44 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/05/07 10:23:44 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>
#include <stdio.h>

void	*ft_memmove(void *dst, const void *src, size_t len)
{
	size_t	i;
	char	*dest;
	char	*source;

	i = 0;
	dest = (char *) dst;
	source = (char *) src;
	if (!src && !dst)
		return (NULL);
	if (dest > source)
	{
		while (len -- > 0)
		{
			dest[len] = source[len];
		}
	}
	else
	{
		while (i < len)
		{
			dest[i] = source[i];
			i++;
		}
	}
	return (dst);
}

/*int main() 
{
    char src[] = "Que Pasa Peña!";
    char dest[20];
    memmove(dest, src, sizeof(src));
    printf("Destination: %s\n", dest);
    return 0;
}*/
