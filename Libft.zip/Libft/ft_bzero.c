/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcanca-m <jcanca-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 10:21:21 by jcanca-m          #+#    #+#             */
/*   Updated: 2024/05/07 10:21:21 by jcanca-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_bzero(void *str, size_t n)
{
	size_t	i;

	i = 0;
	while (i < n)
	{
		((char *)str)[i] = '\0';
		i++;
	}
}
/*#include <stdio.h>

int main()
{
    
    char ptr[] = "holamundo";

    ft_bzero(ptr, 5);

    printf("%s", ptr);
    return (0);
}*/
